The program is written in java.


## Pre Requisties:
Java, maven 

## Build & Run using below command,
cd <project_dir> ; mvn clean install -DskipTests

## Sample Output
![alt text](TestCase1.png)
![alt text](Testcase2.png) 


*************

This version hav included following changes ,
1.Build step 
2.Accept input file as input 
3.Junit Test cases Modified 


(i) mvn clean install -DskipTests -q assembly:single
(ii) run the jar (the one generated under target directory)
     java -jar <path_to>/geektrust.jar <absolute_path_to_input_file>
     
The console prints the log messages followed by output at end
when the file is not provided as input , it takes in the console input for processing.
