package com.app.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.app.command.Command;
import com.app.command.DefaultCommand;

public class CommandProcessor {

	private Map<String, Command> commandMap = new HashMap<String, Command>();

	public void setCommand(String operation, Command command) {
		this.commandMap.put(operation, command);
	}

	public String process(String inputLine) throws Exception {
		String[] inputWords = inputLine.split(" ");
		String operation = inputWords[0];	
		Command command = Optional.ofNullable(this.commandMap.get(operation)).orElse(new DefaultCommand());	
		return command.execute(inputWords);
	}
	
}
