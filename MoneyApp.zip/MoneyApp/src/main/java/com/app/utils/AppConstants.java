package com.app.utils;

public class  AppConstants {
	
	
	public static final String[] inputCommands = {"ALLOCATE","SIP","CHANGE","BALANCE","REBALANCE"};
	public static final String marketChangeObjSuffixKey = "-MR";
	public static final String rebalanceSuffixKey  = "-RB";
	public static final int minRebalanceCount = 6;
	
}
