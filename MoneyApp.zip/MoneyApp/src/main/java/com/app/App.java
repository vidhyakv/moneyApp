package com.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.app.command.AllocateCommand;
import com.app.command.BalanceCommand;
import com.app.command.ChangeCommand;
import com.app.command.RebalanceCommand;
import com.app.command.SIPCommand;
import com.app.utils.CommandProcessor;

public class App {
	static CommandProcessor cmdProcessor;

	public static void main(String[] args) throws Exception {
		cmdProcessor = new CommandProcessor();
		cmdProcessor.setCommand("ALLOCATE", new AllocateCommand());
		cmdProcessor.setCommand("SIP", new SIPCommand());
		cmdProcessor.setCommand("CHANGE", new ChangeCommand());
		cmdProcessor.setCommand("BALANCE", new BalanceCommand());
		cmdProcessor.setCommand("REBALANCE", new RebalanceCommand());

		if (args.length > 0) {

			File inputFile = new File(args[0]);
			List<String> inputLines = new ArrayList<>();
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(inputFile));
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					inputLines.add(line);
				}
				new FileReader(inputFile).close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			inputLines.stream().forEach(arg0 -> {
				try {
					System.out.println(cmdProcessor.process(arg0));
				} catch (Exception e) {
					e.printStackTrace();
				}
			});
		} else {
			Scanner scanner = new Scanner(System.in);
			System.out.print("Type exit to quit - ");
			String inputLine;
			while (scanner.hasNextLine() && !((inputLine = scanner.nextLine()).equals("exit"))) {
				System.out.println(cmdProcessor.process(inputLine));
				
			}
		}

	}
}
