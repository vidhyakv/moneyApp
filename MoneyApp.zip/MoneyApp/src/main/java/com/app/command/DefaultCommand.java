package com.app.command;

public class DefaultCommand extends Command {
	    @Override
	    public String execute(String[] args) {
	       return "Sorry! Your command could not be processed";
	    }
	}


