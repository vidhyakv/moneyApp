package com.app.command;

import com.app.model.MoneyObject;
import com.app.utils.AppConstants;

public class BalanceCommand extends Command {
	@Override
	public String execute(String[] args) {
		//System.out.println(portfolioTracker.toString());
		MoneyObject mo = portfolioTracker.getTarcker().get(args[1]+AppConstants.marketChangeObjSuffixKey);
		String output =  Math.round(mo.getEquityAsset().getAmount()) + " " +Math.round(mo.getDebtAsset().getAmount()) + " "+ Math.round(mo.getGoldAsset().getAmount());		
		return output;
	}

}
