package com.app.command;

import java.util.HashMap;
import java.util.Map;

import com.app.model.Asset;
import com.app.model.MoneyObject;
import com.app.model.PortfolioTracker;

public class AllocateCommand extends Command {

	@Override
	public String execute(String[] args) {

		PortfolioTracker portfolioTracker1 = new PortfolioTracker();

		Map<String, MoneyObject> tracker = new HashMap<String, MoneyObject>();
		double equityAmt =  Double.parseDouble(args[1]);
		double debtAmt =  Double.parseDouble(args[2]);
	    double goldAmt =  Double.parseDouble(args[3]);
		double total = equityAmt + debtAmt  + goldAmt;		
		Asset equityAsset = new Asset(equityAmt,(equityAmt*100)/total );
		Asset debtAsset = new Asset(debtAmt , (debtAmt*100)/total);
		Asset goldAsset = new Asset(goldAmt , (goldAmt*100)/total);
		MoneyObject mo = new MoneyObject(equityAsset, debtAsset, goldAsset);
		mo.setTotalBalance(total);
		tracker.put(args[0], mo);
		portfolioTracker1.setLastMonth(args[0]);
		portfolioTracker1.setTracker(tracker);
		setPortfolioTracker(portfolioTracker1);		
		return "Allocated!";
	}

}
