package com.app.command;

import com.app.model.MoneyObject;
import com.app.utils.AppConstants;

public class ChangeCommand extends Command{

	@Override
	public String execute(String[] args) {
		MoneyObject mo = portfolioTracker.getTarcker().get(portfolioTracker.getLastMonth());
		if(portfolioTracker.getLastMonth().equals("ALLOCATE")){
			MoneyObject moCR = new MoneyObject(mo);
			moCR.getEquityAsset().setChangeRate(Double.parseDouble(args[1].replace("%","")));
			moCR.getDebtAsset().setChangeRate(Double.parseDouble(args[2].replace("%","")));
			moCR.getGoldAsset().setChangeRate(Double.parseDouble(args[3].replace("%","")));			
			portfolioTracker.setLastMonth(args[4]+AppConstants.marketChangeObjSuffixKey);
			portfolioTracker.getTarcker().put(args[4], mo);			
			moCR.amountIncurredviaRateChange();
			portfolioTracker.getTarcker().put(args[4]+AppConstants.marketChangeObjSuffixKey, moCR);	
		}else{
			MoneyObject moMR = new MoneyObject(mo);
			portfolioTracker.getTarcker().put(args[4], mo);
			//apply change Rate
			moMR.getEquityAsset().setChangeRate(Double.parseDouble(args[1].replace("%","")));
			moMR.getDebtAsset().setChangeRate(Double.parseDouble(args[2].replace("%","")));
			moMR.getGoldAsset().setChangeRate(Double.parseDouble(args[3].replace("%","")));			
			
			moMR.applyPayments();
			moMR.amountIncurredviaRateChange();
			portfolioTracker.setLastMonth(args[4]+AppConstants.marketChangeObjSuffixKey);
			portfolioTracker.getTarcker().put(args[4]+AppConstants.marketChangeObjSuffixKey, moMR);	
			
			//calculate rebalance
			MoneyObject moRB =  new MoneyObject(moMR);
			moRB.calcDeviatedRate();
			moRB.doRebalance();
			portfolioTracker.getTarcker().put(args[4]+AppConstants.rebalanceSuffixKey, moRB);			
		}		
		return "Change Rate Applied!";
	}

}
