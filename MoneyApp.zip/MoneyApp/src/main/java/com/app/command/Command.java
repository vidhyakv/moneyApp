package com.app.command;

import com.app.model.PortfolioTracker;

public abstract class Command {

	protected static PortfolioTracker portfolioTracker;

    public static void setPortfolioTracker(PortfolioTracker portfolioTracker) {
        Command.portfolioTracker = portfolioTracker;
    }
	
	public abstract String execute(String[] args);
}
