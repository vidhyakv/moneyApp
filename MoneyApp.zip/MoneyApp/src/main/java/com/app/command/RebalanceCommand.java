package com.app.command;

import com.app.model.MoneyObject;
import com.app.utils.AppConstants;

public class RebalanceCommand extends Command {

	@Override
	public String execute(String[] args) {
		if (portfolioTracker.getTarcker().size() < AppConstants.minRebalanceCount * 3) {
			return "CANNOT_REBALANCE";
		} else {	
			
			MoneyObject mo = portfolioTracker.getTarcker().get(portfolioTracker.getLastMonth().split("-")[0]+AppConstants.rebalanceSuffixKey);
			String output = Math.round(mo.getEquityAsset().getAmount()) + " " + Math.round(mo.getDebtAsset().getAmount()) + " "
					+ Math.round(mo.getGoldAsset().getAmount());			
			return output;

		}
	}

}
