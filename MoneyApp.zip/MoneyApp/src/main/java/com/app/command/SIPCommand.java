package com.app.command;

import com.app.model.MoneyObject;

public class SIPCommand extends Command {

	@Override
	public String execute(String[] args) {		
		MoneyObject mo = portfolioTracker.getTarcker().get("ALLOCATE");
		mo.getEquityAsset().setSiPayment(Double.parseDouble(args[1]));		
		mo.getDebtAsset().setSiPayment(Double.parseDouble(args[2]));
		mo.getGoldAsset().setSiPayment(Double.parseDouble(args[3]));		
		return "Payment added!";
	}

}
