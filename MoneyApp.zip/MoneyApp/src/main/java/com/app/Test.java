import java.io.*;
import java.util.*;
import java.util.regex.*;


public class Test {
    private static final Scanner scan = new Scanner(System.in);
    
    public static void main(String args[]) throws Exception {
        // read the string filename
        String filename;
        filename = scan.nextLine();
        File inputFile = new File(filename);
        List<String> inputLines = new ArrayList<>();
            try {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(inputFile));
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    System.out.println(line);
                    inputLines.add(line);
                }
                new FileReader(inputFile).close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
        
    
}