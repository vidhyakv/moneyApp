package com.app.model;

public class Asset {
	private double siPayment;
	private double originalAllocation;
	private double amount;	
	private double changeRate;	
	private double deviatedRate;
	private double devaitedAmount;
	
	
	public Asset(Asset ast) {
		super();		
		this.amount = ast.getAmount();
		this.siPayment = ast.getSiPayment();
		this.changeRate = ast.getChangeRate();
		this.originalAllocation = ast.getOriginalAllocation();
		this.devaitedAmount =  ast.devaitedAmount;
		
	}
	
	
	public Asset(double amt,double allocation) {
		super();		
		this.amount = amt;
		this.originalAllocation = allocation;
	}
	
	
	public Asset(double siPayment, double amount, double changeRate) {
		super();
		this.siPayment = siPayment;
		this.amount = amount;
		this.changeRate = changeRate;
	}
	
	
		
	
	public double getDevaitedAmount() {
		return devaitedAmount;
	}


	public void setDevaitedAmount(double devaitedAmount) {
		this.devaitedAmount = devaitedAmount;
	}


	public double getOriginalAllocation() {
		return originalAllocation;
	}


	public void setOriginalAllocation(double originalAllocation) {
		this.originalAllocation = originalAllocation;
	}


	public double getSiPayment() {
		return siPayment;
	}
	public void setSiPayment(double siPayment) {
		this.siPayment = siPayment;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getChangeRate() {
		return changeRate;
	}
	public void setChangeRate(double changeRate) {
		this.changeRate = changeRate;
	}


	public double getDeviatedRate() {
		return deviatedRate;
	}


	public void setDeviatedRate(double deviatedRate) {
		this.deviatedRate = deviatedRate;
	}

	
	public void addPayment(){
		this.amount =  this.amount + this.siPayment;
	}

	
	public void doRebalance(){		
		this.amount =  this.amount + this.devaitedAmount;
	}
	@Override
	public String toString() {
		return "siPayment=" + siPayment + ", amount=" + amount + ", changeRate=" + changeRate + ", deviatedRate="
				+ deviatedRate + " devitaedAmount" + devaitedAmount;
	}
	
	
	
	
}
