package com.app.model;

public class MoneyObject {

	// the fund type objects (Equity , debt, gold)
	private Asset equityAsset;
	private Asset debtAsset;
	private Asset goldAsset;
	private Double totalBalance;

	public MoneyObject(Asset equityAsset, Asset debtAsset, Asset goldAsset) {
		super();
		this.equityAsset = equityAsset;
		this.debtAsset = debtAsset;
		this.goldAsset = goldAsset;
	}

	public MoneyObject(MoneyObject mo) {
		super();
		this.equityAsset = new Asset(mo.getEquityAsset());
		this.debtAsset = new Asset(mo.getDebtAsset());
		this.goldAsset = new Asset(mo.getGoldAsset());
		this.totalBalance = mo.getTotalBalance();
	}

	
	/*
	 * This method adds the SIP every month
	 */
	public void applyPayments() {
		this.getEquityAsset().addPayment();
		this.getDebtAsset().addPayment();
		this.getGoldAsset().addPayment();
	}

	/*
	 * This method applies the rate change on the amount - 
	 * Formula - amount + (amount *rate%)/100
	 */
	public void amountIncurredviaRateChange() {
		double equityAmt = this.getEquityAsset().getAmount()
				+ (this.getEquityAsset().getAmount() * this.getEquityAsset().getChangeRate()) / 100;
		double debtAmt = this.getDebtAsset().getAmount()
				+ (this.getDebtAsset().getAmount() * this.getDebtAsset().getChangeRate()) / 100;
		double goldAmt = this.getGoldAsset().getAmount()
				+ (this.getGoldAsset().getAmount() * this.getGoldAsset().getChangeRate()) / 100;
		this.getEquityAsset().setAmount(equityAmt);
		this.getDebtAsset().setAmount(debtAmt);
		this.getGoldAsset().setAmount(goldAmt);
		this.totalBalance = equityAmt + debtAmt + goldAmt;
	}
	
	
    /*
     * This calculates the deviated rate post change along with SIP payments
     */
	public void calcDeviatedRate() {
		
		this.getEquityAsset().setDeviatedRate(this.getEquityAsset().getOriginalAllocation() - (this.getEquityAsset().getAmount() * 100) / this.totalBalance);
		this.getDebtAsset().setDeviatedRate(this.getDebtAsset().getOriginalAllocation() - (this.getDebtAsset().getAmount() * 100) / this.totalBalance);
		this.getGoldAsset().setDeviatedRate(this.getGoldAsset().getOriginalAllocation() - (this.getGoldAsset().getAmount() * 100) / this.totalBalance);
		
		this.getEquityAsset().setDevaitedAmount(this.totalBalance * this.getEquityAsset().getDeviatedRate() / 100);		
		this.getDebtAsset().setDevaitedAmount((this.totalBalance * this.getDebtAsset().getDeviatedRate()) / 100);
		this.getGoldAsset().setDevaitedAmount((this.totalBalance * this.getGoldAsset().getDeviatedRate()) / 100);
		
	}

	/*
	 * This method applies the rebalance logic to set amount across fund types
	 */
	public void doRebalance() {
		
		this.getEquityAsset().doRebalance();
		this.getDebtAsset().doRebalance();
		this.getGoldAsset().doRebalance();
		
	}

	public Asset getEquityAsset() {
		return equityAsset;
	}

	public void setEquityAsset(Asset equityAsset) {
		this.equityAsset = equityAsset;
	}

	public Asset getDebtAsset() {
		return debtAsset;
	}

	public void setDebtAsset(Asset debtAsset) {
		this.debtAsset = debtAsset;
	}

	public Asset getGoldAsset() {
		return goldAsset;
	}

	public void setGoldAsset(Asset goldAsset) {
		this.goldAsset = goldAsset;
	}

	public Double getTotalBalance() {
		return totalBalance;
	}

	public void setTotalBalance(Double totalBalance) {
		this.totalBalance = totalBalance;
	}

	@Override
	public String toString() {
		return "equityAsset=" + equityAsset + ", debtAsset=" + debtAsset + ", goldAsset=" + goldAsset
				+ ", totalBalance=" + totalBalance;
	}

}
