package com.app.model;

import java.util.Map;
import java.util.Optional;

public class PortfolioTracker {

	private String lastMonth;
	private Map<String, MoneyObject> tracker;
	
	
	

	public String getLastMonth() {
		return lastMonth;
	}

	public void setLastMonth(String lastMonth) {
		this.lastMonth = lastMonth;
	}

	public Map<String, MoneyObject> getTarcker() {
		return tracker;
	}

	public void setTracker(Map<String, MoneyObject> tarcker) {
		this.tracker = tarcker;
	}

	@Override
	public String toString() {
		System.out.println("lastMonth"+ lastMonth);
		if (Optional.ofNullable(tracker).isPresent()) {
			tracker.forEach((k, v) -> System.out.println(" Key is  " + k + " value is " + v.toString()));
		}
		return "";
	}

}
