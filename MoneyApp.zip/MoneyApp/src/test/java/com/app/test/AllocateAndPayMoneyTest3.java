package com.app.test;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.app.command.AllocateCommand;
import com.app.command.BalanceCommand;
import com.app.command.ChangeCommand;
import com.app.command.RebalanceCommand;
import com.app.command.SIPCommand;
import com.app.utils.CommandProcessor;

import junit.framework.Assert;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AllocateAndPayMoneyTest3 {

	static CommandProcessor cmdProcessor;

	@BeforeClass
	public static void setUp() throws Exception {
		cmdProcessor = new CommandProcessor();
		System.out.println("Setup called");
		cmdProcessor.setCommand("ALLOCATE", new AllocateCommand());
		cmdProcessor.setCommand("SIP", new SIPCommand());
		cmdProcessor.setCommand("CHANGE", new ChangeCommand());
		cmdProcessor.setCommand("BALANCE", new BalanceCommand());
		cmdProcessor.setCommand("REBALANCE", new RebalanceCommand());
	}

	@Test
	public void testAallocateMoney() {
		try {
			String res = cmdProcessor.process("ALLOCATE 6000 3000 1000");
			Assert.assertEquals("Allocated!", res);
		} catch (Exception e) {
			System.out.println("Exception Caught!");
		}

	}

	@Test
	public void testBaddPayment() {
		try {
			String res = cmdProcessor.process("SIP 2000 1000 500");
			Assert.assertEquals("Payment added!", res);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception Caught while adding payments!");
		}

	}

	@Test
	public void testCapplyChange1() {
		try {
			String res = cmdProcessor.process("CHANGE 4.00% 10.00% 2.00% JANUARY");
			Assert.assertEquals("Change Rate Applied!", res);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception Caught while deriving market change!");
		}

	}

	@Test
	public void testDapplyChange2() {
		try {
			String res = cmdProcessor.process("CHANGE -10.00% 40.00% 0.00% FEBRUARY");
			Assert.assertEquals("Change Rate Applied!", res);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception Caught while deriving market change!");
		}

	}

	

	@Test
	public void testGFetchBalance() {
		try {
			String res = cmdProcessor.process("BALANCE FEBRUARY");
			System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception Caught while deriving market change!");
		}

	}

	@Test
	public void testHFetchReBalance() {
		try {
			String res = cmdProcessor.process("REBALANCE");
			System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception Caught while deriving market change!");
		}

	}
}
